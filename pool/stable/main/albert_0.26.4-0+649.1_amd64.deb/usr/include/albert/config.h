// SPDX-FileCopyrightText: 2024 Manuel Schneider
// SPDX-License-Identifier: MIT

#pragma once
namespace albert
{
static const char * const ALBERT_VERSION_STRING = "0.26.4";
static const int ALBERT_VERSION_MAJOR = 0;
static const int ALBERT_VERSION_MINOR = 26;
static const int ALBERT_VERSION_PATCH = 4;
}

#define ALBERT_PLUGIN_IID "org.albert.PluginInterface/0.26"
