// SPDX-FileCopyrightText: 2024 Manuel Schneider
// SPDX-License-Identifier: MIT

#pragma once
namespace albert
{
static const char * const ALBERT_VERSION_STRING = "34.0.10";
static const int ALBERT_VERSION_MAJOR = 34;
static const int ALBERT_VERSION_MINOR = 0;
static const int ALBERT_VERSION_PATCH = 10;
}
