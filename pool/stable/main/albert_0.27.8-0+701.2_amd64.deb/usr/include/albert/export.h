
#ifndef ALBERT_EXPORT_H
#define ALBERT_EXPORT_H

#ifdef ALBERT_STATIC_DEFINE
#  define ALBERT_EXPORT
#  define ALBERT_NO_EXPORT
#else
#  ifndef ALBERT_EXPORT
#    ifdef libalbert_EXPORTS
        /* We are building this library */
#      define ALBERT_EXPORT __attribute__((visibility("default")))
#    else
        /* We are using this library */
#      define ALBERT_EXPORT __attribute__((visibility("default")))
#    endif
#  endif

#  ifndef ALBERT_NO_EXPORT
#    define ALBERT_NO_EXPORT __attribute__((visibility("hidden")))
#  endif
#endif

#ifndef ALBERT_DEPRECATED
#  define ALBERT_DEPRECATED __attribute__ ((__deprecated__))
#endif

#ifndef ALBERT_DEPRECATED_EXPORT
#  define ALBERT_DEPRECATED_EXPORT ALBERT_EXPORT ALBERT_DEPRECATED
#endif

#ifndef ALBERT_DEPRECATED_NO_EXPORT
#  define ALBERT_DEPRECATED_NO_EXPORT ALBERT_NO_EXPORT ALBERT_DEPRECATED
#endif

#if 0 /* DEFINE_NO_DEPRECATED */
#  ifndef ALBERT_NO_DEPRECATED
#    define ALBERT_NO_DEPRECATED
#  endif
#endif

#endif /* ALBERT_EXPORT_H */
