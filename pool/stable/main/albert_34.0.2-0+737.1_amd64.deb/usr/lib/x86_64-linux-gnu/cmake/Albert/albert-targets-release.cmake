#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "albert::libalbert" for configuration "Release"
set_property(TARGET albert::libalbert APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(albert::libalbert PROPERTIES
  IMPORTED_LINK_DEPENDENT_LIBRARIES_RELEASE "Qt6::Concurrent;Qt6::Core;Qt6::Network;Qt6::Sql;Qt6::Widgets"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/x86_64-linux-gnu/libalbert.so.34.0.2"
  IMPORTED_SONAME_RELEASE "libalbert.so.34.0"
  )

list(APPEND _cmake_import_check_targets albert::libalbert )
list(APPEND _cmake_import_check_files_for_albert::libalbert "${_IMPORT_PREFIX}/lib/x86_64-linux-gnu/libalbert.so.34.0.2" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
