// SPDX-FileCopyrightText: 2024 Manuel Schneider
// SPDX-License-Identifier: MIT

#pragma once
namespace albert
{
static const char * const ALBERT_VERSION_STRING = "0.27.8";
static const int ALBERT_VERSION_MAJOR = 0;
static const int ALBERT_VERSION_MINOR = 27;
static const int ALBERT_VERSION_PATCH = 8;
}

#define ALBERT_PLUGIN_IID "org.albert.PluginInterface/0.27"
